import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  Injectable,
  ViewChild,
} from "@angular/core";
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours,
  subWeeks,
  addWeeks,
  addMonths,
  subMonths,
  startOfWeek,
  startOfMonth,
  endOfWeek,
  isToday,
  differenceInCalendarMonths,
  isWeekend,
} from "date-fns";
import { Subject } from "rxjs";
import {
  CalendarEvent,
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView,
  CalendarViewPeriod,
  CalendarMonthViewDay,
} from "angular-calendar";
import { RolesService } from "src/app/modules/system/configs/roles.service";
import { AppConstants } from "src/app/constants/AppConstants";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { HrService } from "src/app/modules/system/dashboards/hr.service";
import { OverallLeaveListComponent } from "../overall-leave-list/overall-leave-list.component";
import { UserLeaveListComponent } from "../user-leave-list/user-leave-list.component";

@Component({
  selector: "app-hr-attendance",
  templateUrl: "./hr-attendance.component.html",
  styleUrls: ["./hr-attendance.component.scss"],
})
export class HrAttendanceComponent implements OnInit {
  @ViewChild(OverallLeaveListComponent, { static: false })
  overallLeaveListComponent: OverallLeaveListComponent;
  @ViewChild(UserLeaveListComponent, { static: false })
  userLeaveListComponent: UserLeaveListComponent;
  //@Output("dateChange") dateChange: EventEmitter<any> = new EventEmitter<any>();

  CalendarView = CalendarView;
  viewDate: Date = new Date();
  activeDayIsOpen: boolean = true;
  view: CalendarView | CalendarViewPeriod = CalendarView.Month;
  //minDate: Date = subMonths(new Date(), 1);
  //maxDate: Date = new Date();
  prevBtnDisabled: boolean = false;
  nextBtnDisabled: boolean = false;
  users: any;
  user: any;
  allowUserSearch: boolean = true;
  isUserSelected: boolean;
  leaveInfo: any;
  events: any;
  constructor(
    private rolesService: RolesService,
    private hrService: HrService,
    private helperService: HelperService
  ) {}

  ngOnInit() {
    this.prepareData();
  }

  async prepareData() {
    if (this.allowUserSearch) {
      await this.getUsersByPrivilege(AppConstants.ARTIST_PRIVILEGE_ID);
      await this.getLeaveInfo();
    } else {
      this.isUserSelected = true;
    }
  }

  async getUsersByPrivilege(privilegeId: any) {
    await this.rolesService
      .getUsersByPrivilege(privilegeId)
      .toPromise()
      .then((resp: any) => {
        this.users = resp.entity;
      })
      .catch((error: any) => {
        this.users = [];
      });
  }

  async getLeaveInfo() {
    let m = this.helperService._getMonth(this.viewDate);
    let y = this.viewDate.getFullYear();
    await this.hrService
      .getLeaveInfo(m, y)
      .toPromise()
      .then((resp: any) => {
        this.leaveInfo = resp.entity;
        this.frameEvents();
      })
      .catch((error: any) => {
        this.leaveInfo = [];
      });
  }

  async getLeaveInfoByArtist(userId: any) {
    let m = this.helperService._getMonth(this.viewDate);
    let y = this.viewDate.getFullYear();
    await this.hrService
      .getLeaveInfoByArtist(m, y, userId)
      .toPromise()
      .then((resp: any) => {
        this.leaveInfo = resp.entity;
        this.frameEvents();
      })
      .catch((error: any) => {
        this.leaveInfo = [];
      });
  }

  frameEvents() {
    this.events = [];
    if (this.leaveInfo && this.leaveInfo.length > 0) {
      for (let index = 0; index < this.leaveInfo.length; index++) {
        this.addLogEvent(
          this.leaveInfo[index].appliedDate,
          JSON.stringify(this.leaveInfo[index])
        );
      }
    }
  }

  addLogEvent(date: any, details: any): void {
    this.events = [
      ...this.events,
      {
        title: details,
        start: new Date(date),
        end: new Date(date),
        draggable: false,
        resizable: {
          beforeStart: false,
          afterEnd: false,
        },
      },
    ];
  }

  onListChange(e: any) {
    this.getLeaveInfoByArtist(this.user.id);
  }

  userChangeHandler(e) {
    this.user = e;
    this.isUserSelected = true;
    if (this.user) {
      this.getLeaveInfoByArtist(this.user.id);
    }
  }

  getAvatarInfo(user: any) {
    return {
      firstName: user.firstName,
      lastName: user.lastName,
      thumbnail: user.thumbnail,
      size: "large",
    };
  }

  getUserName(user) {
    let name = "";
    if (user.firstName) {
      name += user.firstName + " ";
    }
    if (user.lastName) {
      name += user.lastName;
    }
    return name;
  }

  closeUser() {
    this.isUserSelected = false;
    this.user = null;
    this.getLeaveInfo();
    //this.userClose.emit(null);
  }

  isValidArr(users: any) {
    return this.helperService.isValidArr(users);
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    this.viewDate = date;
    if (this.isUserSelected) {
      //alert("Update Table ???? ");
    } else {
      this.overallLeaveListComponent.updateTable(this.viewDate);
    }
    /*let event = {
      date: this.viewDate,
      isMonthChange: false,
    };
    this.dateChange.emit(event);*/
  }

  beforeMonthViewRender({ body }: { body: CalendarMonthViewDay[] }): void {
    body.forEach((day) => {
      if (!this.dateIsValid(day)) {
        day.cssClass = "cal-disabled";
      }
    });
  }

  dateIsValid(day: any): boolean {
    let date = day.date;
    /*if (isWeekend(date)) {
      return false;
    }*/

    if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (logEvent.hasOwnProperty("offType")) {
        return false;
      }
    }
    if (isSameMonth(date, this.viewDate)) {
      return true;
    }
    return false;
  }

  deleteEvent(eventToDelete: CalendarEvent) {
    this.events = this.events.filter((event) => event !== eventToDelete);
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
    /*let event = {
      date: this.viewDate,
      isMonthChange: true,
    };
    this.dateChange.emit(event);*/
    if (this.isUserSelected) {
      //alert("Update Table ???? ");
      this.getLeaveInfoByArtist(this.user.id);
      this.userLeaveListComponent.updateTable(this.viewDate);
    } else {
      this.getLeaveInfo();
      this.overallLeaveListComponent.updateTable(this.viewDate);
    }
  }

  getTitle(day) {
    if (day && day.events && day.events.length > 0) {
      return day.events[0].title;
    } else {
      return "no event";
    }
  }

  isSelected(day: any) {
    return isSameDay(this.viewDate, day.date);
  }

  isClickable(day: any) {
    if (day && day.cssClass && day.cssClass == "cal-disabled") {
      return false;
    }
    return true;
  }

  getHours(day: any) {
    // if (day && day.events && day.events.length > 0) {
    //   let logEvent = JSON.parse(day.events[0].title);
    //   if (logEvent.hoursWorked) {
    //     return `0${logEvent.hoursWorked} hrs`;
    //   }
    // }
    // return '00 hrs';
    if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (logEvent.hoursWorked) {
        return logEvent.hoursWorked;
        //return `0${logEvent.hoursWorked} hrs`;
      }
    }
    return 0;
  }

  getPercent(day: any) {
    if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (logEvent.completionPercentage) {
        return `${logEvent.completionPercentage} %`;
      }
    }
    return "0 %";
  }

  getLoggedPercent(day: any) {
    /*if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (logEvent.hoursWorked) {
        return Math.round(logEvent.hoursWorked * 100 / AppConstants.HOURS_PER_DAY);
      }
    }
    return '0 %';*/
    return Math.round((this.getHours(day) * 100) / AppConstants.HOURS_PER_DAY);
  }

  getLeaveStatus(day: any) {
    /*if (day.isWeekend) {
      return "OFF";
    }
    if (day && day.cssClass && day.cssClass == "cal-disabled") {
      return "-NA-";
    }*/
    if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (logEvent.hasOwnProperty("offType")) {
        return logEvent.offType;
        /*if (logEvent.offType === "Holiday") {
          return "OFF";
        } else {
          return logEvent.offType;
        }*/
      }
    } else {
      if (day && day.cssClass && day.cssClass == "cal-disabled") {
        return "-NA-";
      }
      return `Available`;
    }
  }

  getOverallPercent(day: any) {
    /*if (day.isWeekend) {
      return "OFF";
    }*/

    if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (!logEvent.hasOwnProperty("offType")) {
        return `${logEvent.overAllPer} %`;
      } else {
        //return `OFF`;
        let offType = `OFF`;
        if (logEvent.offType) {
          offType = logEvent.offType;
        }
        return offType;
      }
    }
    if (day && day.cssClass && day.cssClass == "cal-disabled") {
      return "-NA-";
    }
    return "100 %";
  }

  getStatus(day: any) {
    /*if (day.isWeekend) {
      return "week-end";
    }
    if (day && day.cssClass && day.cssClass == "cal-disabled") {
      return "cell-na";
    }*/
    if (day && day.events && day.events.length > 0) {
      let logEvent = JSON.parse(day.events[0].title);
      if (!this.isUserSelected) {
        if (!logEvent.hasOwnProperty("offType")) {
          if (logEvent.hasOwnProperty("overAllPer")) {
            if (logEvent.overAllPer == 100) {
              return "full";
            } else if (logEvent.overAllPer > 0 && logEvent.overAllPer < 100) {
              return "partial";
            } else {
              return "empty";
            }
          }
        } else {
          return "day-off";
        }
      } else {
        if (logEvent.hasOwnProperty("offType")) {
          if (
            logEvent.offType === "Holiday" ||
            logEvent.offType === "Weekend"
          ) {
            return "day-off";
          } else {
            return "leave";
          }
        } else {
          return "full";
        }
      }
    } else {
      if (!this.isUserSelected) {
        return "full";
      } else {
        return "full";
      }
    }
  }

  disabledPrev() {
    /*if (isSameMonth(subDays(new Date(), 14), new Date())) {
      return true;
    }
    if (differenceInCalendarMonths(new Date(), this.viewDate) >= 1) {
      return true;
    }*/
    return false;
  }
  disableNext() {
    /*if (isToday(this.viewDate)) {
      return true;
    }
    if (isSameMonth(this.viewDate, new Date())) {
      return true;
    }*/
    return false;
  }
}
